package com.capgemini.myapp.controller;

import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

import com.capgemini.myapp.model.Customer;
import com.capgemini.myapp.model.LoanRequest;

public class EmployeeService {

	Scanner input= new Scanner(System.in);
	public List<Customer> createAccount(List<Customer> list) {
		try {
			Customer cs=new Customer();
			System.out.println("Enter Custeomer Id");
			String customerId=input.nextLine();

			System.out.println("Enter Custeomer password");
			String customerpass=input.nextLine();
			System.out.println("Enter customerName ");
			String customerName=input.nextLine();
			System.out.println("Enter customerAddress ");
			String customerAddress=input.nextLine();
			System.out.println("Enter customerAadhar ");
			String customerAadhar=input.nextLine();
			System.out.println("Enter customerPan ");
			String customerPan=input.nextLine();
			System.out.println("Enter customerContact ");
			String customerContact=input.nextLine();
			System.out.println("Enter customerGender ");
			String customerGender=input.nextLine();
			System.out.println("Enter date of birth in dd/MM/yyyy format ");
			String d=input.nextLine();
			Date date= new SimpleDateFormat("dd/MM/yyyy").parse(d);
			System.out.println("Enter net worth ");
			
			Double amount =input.nextDouble();
			
			cs.setCustid(customerId);
			cs.setCustname(customerName);	
			cs.setCustaddress(customerAddress);
			cs.setAadhar(customerAadhar);
			cs.setPan(customerPan);
			cs.setContact(customerContact);
			cs.setDob(date);
			cs.setGender(customerGender);
			cs.setAmount(amount);
			cs.setCustpass(customerpass);
			list.add(cs);
			

			System.out.println("Account created Sucessfully ...");
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		return list;
	}
	public List<Customer> deleteAccount(List<Customer> list) {
		System.out.println("enter customer  id to delete ");
		 String  customerId=input.nextLine();
		List<Customer> filteredCollection = list
				  .stream()
				  .filter(cust -> !cust.getCustid().equals(customerId))
				  .collect(Collectors.toList());
		System.out.println("Account deleted ....");
		//System.out.println(filteredCollection);
		return filteredCollection;
	}
	public List<Customer> update(List<Customer> list) {
		try {
			System.out.println("Enter customerId to update account...");
			String customerId=input.nextLine();
			int flag=0;
			for(Customer customer:list) {
				if(customer.getCustid().equals(customerId)) {
					System.out.println("enter  customer  address and customer contact");
					String customerAddress=input.nextLine();
					String customerContact=input.nextLine();
					customer.setCustaddress(customerAddress);
					customer.setContact(customerContact);
					flag=1;
				}
			}
			if(flag!=0) {
				System.out.println("Employee details updated  Sucessfully .....");
			}else {
				System.out.println("Geven details doesn't match with any  customer ");
			}
		}catch(Exception e) {
		e.printStackTrace();
		}
		return list;

}
public List<Customer> viewDetails(List<Customer> list) {
	try {
		System.out.println("Enter customerId to View account details2...");
		String customerId=input.nextLine();
		int flag=0;
		for(Customer customer:list) {
			if(customer.getCustid().equals(customerId)) {
				System.out.println("CustomerId -> "+customer.getCustid()+" \n Customer Name ->"+customer.getCustname()
				+" \n Customer Address -> "+customer.getCustaddress()+"\n customer Aadhar -> "+customer.getAadhar()
				+"\n customer Pan -> "+customer.getPan()+"\n customer Gender -> "+customer.getGender()+" \n Customer dob->"+customer.getDob()
				+"\n customer contact "+customer.getContact());
				flag=1;
			}
		}
		if(flag==0) {
			System.out.println("Geven details doesn't match with any  customer ...");
		}
	}catch(Exception e) {
		e.printStackTrace();
	}
	return list;
}
	public List<Customer> verifyLoanDetails(List<Customer> list) {
		
		int flag=0;
		  System.out.println("enter id of customer :");
		  String str=input.nextLine();
		  for(Customer cst:list)
		  { 
			  if(cst.getCustid().equals(str))
			  {
				  flag=1;
		  System.out.println("enter amount of loan customer want "); 
		  Double amt=input.nextDouble();
		  if(amt<cst.getAmount()-20)
		  { cst.setLoanamount(amt);
		  System.out.println("loan granted...."); 
		  } else 
		  {
		  System.out.println("loan rejected...");
		  }
		  
		  }
		  
		  
			  
		  }if(flag==0)
			  System.out.println("no such customer exist...."); 
		 
		 LoanRequest loan= new LoanRequest();
			
		return list;
	}
}
