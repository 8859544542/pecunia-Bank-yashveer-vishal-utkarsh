package com.capgemini.myapp.dao;

import java.io.File;
import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.capgemini.myapp.model.Customer;
import com.capgemini.myapp.model.Employee;

public class DataCollection implements Serializable {

	public List<Object> getData() {
	boolean b1 = false;
	boolean b2 = false;

	FileInputStream fout = null;
	ObjectInputStream oos = null;

	List<Employee> employee = new ArrayList();
	List<Customer> customer = new ArrayList();
try {

		File fc = new File(LocationInfo.pathCustomer);
		File fe = new File(LocationInfo.pathEmployee);

		b1 = fc.exists();
		b2 = fe.exists();

	} catch (Exception e) {
		// TODO: handle exception
	}

	if (b1 && b2)

	{
		try {
			fout = new FileInputStream(LocationInfo.pathCustomer);
			oos = new ObjectInputStream(fout);
			Object obj = oos.readObject();
			if (obj != null) {
				customer = (List<Customer>) obj;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			fout = new FileInputStream(LocationInfo.pathEmployee);
			oos = new ObjectInputStream(fout);
			Object obj = oos.readObject();
			if (obj != null) {
				employee = (List<Employee>) obj;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	} 
		List<Object> list=new ArrayList<Object>();
		list.add(customer);
		list.add(employee);
		return list;
	}
	
}
