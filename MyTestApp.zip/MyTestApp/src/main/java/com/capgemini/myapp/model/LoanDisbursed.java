package com.capgemini.myapp.model;

import java.util.Date;

public class LoanDisbursed {
	private String loanrequestid;
	private String customerid;
	private Double loanamount;
	private String loantype;
	Double loanamountpaid;
	private Date loanduedate;
	private Double loanemi;
	public LoanDisbursed() {
		super();
		
	}
	public LoanDisbursed(String loanrequestid, String customerid, Double loanamount, String loantype,
			Double loanamountpaid, Date loanduedate, Double loanemi) {
		super();
		this.loanrequestid = loanrequestid;
		this.customerid = customerid;
		this.loanamount = loanamount;
		this.loantype = loantype;
		this.loanamountpaid = loanamountpaid;
		this.loanduedate = loanduedate;
		this.loanemi = loanemi;
	}
	public String getLoanrequestid() {
		return loanrequestid;
	}
	public void setLoanrequestid(String loanrequestid) {
		this.loanrequestid = loanrequestid;
	}
	public String getCustomerid() {
		return customerid;
	}
	public void setCustomerid(String customerid) {
		this.customerid = customerid;
	}
	public Double getLoanamount() {
		return loanamount;
	}
	public void setLoanamount(Double loanamount) {
		this.loanamount = loanamount;
	}
	public String getLoantype() {
		return loantype;
	}
	public void setLoantype(String loantype) {
		this.loantype = loantype;
	}
	public Double getLoanamountpaid() {
		return loanamountpaid;
	}
	public void setLoanamountpaid(Double loanamountpaid) {
		this.loanamountpaid = loanamountpaid;
	}
	public Date getLoanduedate() {
		return loanduedate;
	}
	public void setLoanduedate(Date loanduedate) {
		this.loanduedate = loanduedate;
	}
	public Double getLoanemi() {
		return loanemi;
	}
	public void setLoanemi(Double loanemi) {
		this.loanemi = loanemi;
	}
	
}
