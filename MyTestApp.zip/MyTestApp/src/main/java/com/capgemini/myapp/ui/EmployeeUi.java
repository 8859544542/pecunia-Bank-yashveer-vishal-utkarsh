package com.capgemini.myapp.ui;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.capgemini.myapp.controller.EmployeeService;
import com.capgemini.myapp.dao.LocationInfo;
import com.capgemini.myapp.model.Customer;
import com.capgemini.myapp.model.Employee;

public class EmployeeUi {
	Scanner sc= new Scanner(System.in);
	public void Employeelogin(List<Employee> employee, List<Customer> customer)
	
	{

		int flag=0,i;
		 System.out.println("enter user id ...");
		 String id=sc.nextLine();
		 System.out.println("enter user password...");
		 String password=sc.nextLine();
		 for(Employee em:employee)
		 {
			
		 if(id.equals(em.getEmpid()) && password.equals(em.getPassword()))
		 {
			 /*do
			 {*/
		    flag=1;
			System.out.println("press 1 for create  account ");
			System.out.println("press 2 for delete   account ");
			System.out.println("press 3 for update   account ");
			System.out.println("press 4 for view account Details   ");
			System.out.println("press 5 for verify loan request user ");
			System.out.println("press 6 for exit");
			int n=sc.nextInt();
			sc.nextLine();
			List<Customer> cust=customer;
			
			switch(n) {
				case 1:
						try {
							EmployeeService empservice = new EmployeeService();
							cust=empservice.createAccount(customer);
							System.out.println("---------------------------------------");
							break;
						}catch(Exception e){
							e.printStackTrace();
						}
				case 2:
						try {
							EmployeeService empservice = new EmployeeService();
							//System.out.println(customer);
							cust=empservice.deleteAccount(customer);
							//System.out.println(cust);
							System.out.println("---------------------------------------");
							break;
						}catch(Exception e){
							e.printStackTrace();
						}
				case 3:
						try {
							EmployeeService empservice = new EmployeeService();
							cust=empservice.update(customer);
							System.out.println("---------------------------------------");
							break;
						}catch(Exception e){
							e.printStackTrace();
						}
			
				case 4:
						try {
							EmployeeService empservice = new EmployeeService();
							cust=empservice.viewDetails(customer);
							System.out.println("---------------------------------------");
							break;
						}catch(Exception e){
							e.printStackTrace();
						}
				case 5:
						try {
							EmployeeService empservice = new EmployeeService();
							cust=empservice.verifyLoanDetails(customer);
							System.out.println("---------------------------------------");
							break;
						}catch(Exception e){
							e.printStackTrace();
						}
				case 6:
					    System.exit(0);
					    break;
				default :
						System.out.println("NO such operation is mention above...");
		
			}
			try {
				FileOutputStream fout = new FileOutputStream(LocationInfo.pathEmployee);
			 	ObjectOutputStream oos = new ObjectOutputStream(fout);
			 	try {
					oos.writeObject(employee);
					
				} catch (IOException e) {
					e.printStackTrace();
				}
			}catch(Exception e) {
				e.printStackTrace();
			}
			try {
				FileOutputStream fout = new FileOutputStream(LocationInfo.pathCustomer);
			 	ObjectOutputStream oos = new ObjectOutputStream(fout);
			 	try {
			 		//System.out.println(cust);
					oos.writeObject(cust);
				} catch (IOException e) {
					e.printStackTrace();
				}
			}catch(Exception e) {
				e.printStackTrace();
			}
			
			 System.out.println("press 9 for continue  ");
			 i=sc.nextInt();
				/* }while(i==9); */
		 

				
		 }
		
		 }
		 if(flag==0)
			 System.out.println("no such employee exist...");

	}
}
