package com.capgemini.myapp.model;

public class Branch {
	private String branchid;
	private String branchname;
	private String branchifsc;
	private Address branchaddress;
	public Branch() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Branch(String branchid, String branchname, String branchifsc, Address branchaddress) {
		super();
		this.branchid = branchid;
		this.branchname = branchname;
		this.branchifsc = branchifsc;
		this.branchaddress = branchaddress;
	}
	public String getBranchid() {
		return branchid;
	}
	public void setBranchid(String branchid) {
		this.branchid = branchid;
	}
	public String getBranchname() {
		return branchname;
	}
	public void setBranchname(String branchname) {
		this.branchname = branchname;
	}
	public String getBranchifsc() {
		return branchifsc;
	}
	public void setBranchifsc(String branchifsc) {
		this.branchifsc = branchifsc;
	}
	public Address getBranchaddress() {
		return branchaddress;
	}
	public void setBranchaddress(Address branchaddress) {
		this.branchaddress = branchaddress;
	}
}
