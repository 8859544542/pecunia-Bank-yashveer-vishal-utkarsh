package com.capgemini.myapp.dao;

import java.io.Serializable;

public class LocationInfo implements Serializable {

	public static String pathCustomer = "C:\\STS\\MyTestApp\\src\\main\\resources\\customer.txt";
	public static String pathEmployee = "C:\\STS\\MyTestApp\\src\\main\\resources\\employee.txt";
	
}
