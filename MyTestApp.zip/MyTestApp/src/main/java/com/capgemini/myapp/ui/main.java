package com.capgemini.myapp.ui;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.ObjectInputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.capgemini.myapp.controller.CustomerService;
import com.capgemini.myapp.dao.DataCollection;
import com.capgemini.myapp.dao.LocationInfo;
import com.capgemini.myapp.model.Customer;
import com.capgemini.myapp.model.Employee;

public class main implements Serializable {

	public static void main(String[] args) {

		DataCollection dc=new DataCollection();
		List<Object> list =dc.getData();
		ArrayList<Customer> customer=(ArrayList<Customer>) list.get(0);
		
		ArrayList<Employee> employee=(ArrayList<Employee>) list.get(1);
		
		while(true)
		{
			

			System.out.println("1 For Manager ");
			System.out.println("2 For Employee ");
			System.out.println("3 For Customer ");
			System.out.println("0 EXIT");
			
			System.out.println("\n Enter Your Choice :- ");
			Scanner scanner = new Scanner(System.in);
			
			switch (scanner.nextInt()) {
			case 1:
				try {
					new ManagerUi().login(employee, customer);
				} catch (FileNotFoundException e) {
					e.printStackTrace();
				}
				break;
			case 2:
				new EmployeeUi().Employeelogin(employee, customer);
				break;
			case 3:
				new CustomerUi().customerLogin(customer);
				break;
			case 0:
				System.exit(0);
				break;

			default:
				System.out.println("wrong choice....");

			}//end switch
			
			System.out.println(" Press Any Key To Continue .....");
			scanner.next();
			
			System.out.println("______________________________________________________");
		}//end of while		
		
	
		

	}//end main
}// end class
