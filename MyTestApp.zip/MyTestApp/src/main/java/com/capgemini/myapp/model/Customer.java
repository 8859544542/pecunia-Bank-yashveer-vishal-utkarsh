package com.capgemini.myapp.model;

import java.io.Serializable;
import java.util.Date;

public class Customer implements Serializable{

private String custid;
private String custname;
private String custaddress;
private String aadhar;
private String pan;
private String contact;
private Date dob;
private String gender;
private String custpass;
private Double amount;
private Double loanamount;


public Double getAmount() {
	return amount;
}
public void setAmount(Double amount) {
	this.amount = amount;
}
public Customer() {
	super();
	// TODO Auto-generated constructor stub
}
public Customer(String custid,Double loanamount,String custpass, String custname, String custaddress, String aadhar, String pan, String contact, Date dob,
		String gender) {
	super();
	this.custid = custid;
	this.custname = custname;
	this.custaddress = custaddress;
	this.aadhar = aadhar;
	this.pan = pan;
	this.contact = contact;
	this.dob = dob;
	this.gender = gender;
	this.custpass=custpass;
	this.loanamount=loanamount;
}
public Double getLoanamount() {
	return loanamount;
}
public void setLoanamount(Double loanamount) {
	this.loanamount = loanamount;
}
public String getCustpass() {
	return custpass;
}
public void setCustpass(String custpass) {
	this.custpass = custpass;
}
public String getCustid() {
	return custid;
}
public void setCustid(String custid) {
	this.custid = custid;
}
public String getCustname() {
	return custname;
}
public void setCustname(String custname) {
	this.custname = custname;
}
public String getCustaddress() {
	return custaddress;
}
public void setCustaddress(String custaddress) {
	this.custaddress = custaddress;
}
public String getAadhar() {
	return aadhar;
}
public void setAadhar(String aadhar) {
	this.aadhar = aadhar;
}
public String getPan() {
	return pan;
}
public void setPan(String pan) {
	this.pan = pan;
}
public String getContact() {
	return contact;
}
public void setContact(String contact) {
	this.contact = contact;
}
public Date getDob() {
	return dob;
}
public void setDob(Date dob) {
	this.dob = dob;
}
public String getGender() {
	return gender;
}
public void setGender(String gender) {
	this.gender = gender;
}
}
