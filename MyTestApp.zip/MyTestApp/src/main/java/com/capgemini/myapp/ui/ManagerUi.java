package com.capgemini.myapp.ui;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.capgemini.myapp.controller.ManagerService;
import com.capgemini.myapp.dao.LocationInfo;
import com.capgemini.myapp.model.Customer;
import com.capgemini.myapp.model.Employee;

public class ManagerUi implements Serializable {
	Scanner scanner = new Scanner(System.in);

	public void login(List<Employee> employee, List<Customer> customer) throws FileNotFoundException { // 101,102,103
		int i;
		System.out.println("enter user id ...");
		int id = scanner.nextInt();
		scanner.nextLine();
		System.out.println("enter user password...");
		String password = scanner.nextLine();
		if (id == 123 && password.equals("123")) {
		//	while (true) {
				System.out.println("1 for view All Customer ");
				System.out.println("2 for total Loan Report");
				System.out.println("3 for create Employee ");
				System.out.println("4 for delete Employee");
				System.out.println("5 for view Customer ");
				System.out.println("6 for view Employee ");
				System.out.println("7 for quit");
				Scanner scanner = new Scanner(System.in);
				ManagerService ms = new ManagerService();
				List<Employee> emp = employee;// 101,102,103
				List<Customer> cust = customer;
				switch (scanner.nextInt()) {
				case 1:
					cust = ms.viewAllCustomer(customer);
					System.out.println("---------------------------------------");
					break;
				case 2:
					cust = ms.totalLoanReport(customer);
					System.out.println("---------------------------------------");
					break;
				case 3:
					emp = ms.createEmployee(employee);
					System.out.println("---------------------------------------");
					break;
				case 4:
					emp = ms.deleteEmployee(employee);// 101,102,103
					/*
					 * System.out.println(emp.size()); for (Employee e : emp) {
					 * System.out.println(e); }
					 */
					System.out.println("---------------------------------------");
					break;
				case 5:
					cust = ms.viewCustomer(customer);
					System.out.println("---------------------------------------");
					break;
				case 6:
					emp = ms.viewAllEmployee(employee);

					System.out.println("---------------------------------------");
					break;
				case 7:
					System.exit(0);
					break;
				default:
					System.out.println("wrong choice....");

				}// end switch
				try {
					/* System.out.println("\n\n\n -------- Inside Ser --- code -----\n\n"); */
					FileOutputStream fout = new FileOutputStream(LocationInfo.pathEmployee);
					ObjectOutputStream oos = new ObjectOutputStream(fout);
					try {
						/*
						 * System.out.println(" ---->> saving emp with size " + emp.size()); for
						 * (Employee e : emp) { System.out.println(e); }
						 */
						oos.writeObject(emp);
					} catch (IOException e) {
						e.printStackTrace();
					}
				} catch (Exception e) {
					e.printStackTrace();
				}

				try {
					FileOutputStream fout = new FileOutputStream(LocationInfo.pathCustomer);
					ObjectOutputStream oos = new ObjectOutputStream(fout);
					try {
						oos.writeObject(cust);
					} catch (IOException e) {
						e.printStackTrace();
					}
				} catch (Exception e) {
					e.printStackTrace();
				}

				System.out.println("press Any key for continue ...");
			//	scanner.next();
			//} // end of while
		} // end of if manager
		else
			System.out.println("Invalid User Id and password ");

	}// end of method
}// end class
