package com.capgemini.myapp.model;

public class LoanRequest {
	private String loanrequestid;
	private String customerid;
	private Double loanamount;
	private String loantype;
	private String loanstatus;
	private Double loanemi;
	public LoanRequest() {
		super();
		// TODO Auto-generated constructor stub
	}
	public LoanRequest(String loanrequestid, String customerid, Double loanamount, String loantype, String loanstatus,
			Double loanemi) {
		super();
		this.loanrequestid = loanrequestid;
		this.customerid = customerid;
		this.loanamount = loanamount;
		this.loantype = loantype;
		this.loanstatus = loanstatus;
		this.loanemi = loanemi;
	}
	public String getLoanrequestid() {
		return loanrequestid;
	}
	public void setLoanrequestid(String loanrequestid) {
		this.loanrequestid = loanrequestid;
	}
	public String getCustomerid() {
		return customerid;
	}
	public void setCustomerid(String customerid) {
		this.customerid = customerid;
	}
	public Double getLoanamount() {
		return loanamount;
	}
	public void setLoanamount(Double loanamount) {
		this.loanamount = loanamount;
	}
	public String getLoantype() {
		return loantype;
	}
	public void setLoantype(String loantype) {
		this.loantype = loantype;
	}
	public String getLoanstatus() {
		return loanstatus;
	}
	public void setLoanstatus(String loanstatus) {
		this.loanstatus = loanstatus;
	}
	public Double getLoanemi() {
		return loanemi;
	}
	public void setLoanemi(Double loanemi) {
		this.loanemi = loanemi;
	}

}
