package com.capgemini.myapp.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

import com.capgemini.myapp.model.Customer;
import com.capgemini.myapp.model.Employee;

public class ManagerService {
	  Scanner scanner=new Scanner(System.in);
      public List<Customer> viewAllCustomer(List<Customer> customer )
      {
    	  if(customer!=null)
    	  {
	    	  for(Customer c:customer)
	    	  {
	    		  System.out.println("customerId : "+c.getCustid()+"  "+"customerName : "+c.getCustname()+"  "+"customerContact : "+c.getContact());
	    		  System.out.println("---------------------------------------");
	    	  }
    	  System.out.println("done.....");
    	  }
    	  else
    		  System.out.println("no customer exist...");
    	  return customer;
      }
      public List<Employee> viewAllEmployee(List<Employee> employee )
      {
    	  for(Employee c:employee)
    	  {
    		  System.out.println("Employee Id  : "+c.getEmpid()+"  "+"Employee Name  : "+c.getEmpname()+"Branch Id :"+c.getBranchid());
    		  System.out.println("---------------------------------------");
    	  }
    	  System.out.println("done.....");
    	  return employee;
      }
      public List<Customer> totalLoanReport(List<Customer> customer )
      {
    	  Double loan = 0.0;
    	  for(Customer cst:customer)
    	  {
    		  if(cst.getLoanamount()!=null )
    		  {
    			  loan=loan+cst.getLoanamount();
    					  
    		  }
    	  }
    	  System.out.println("Bank distribute total loan of  :"+loan);
    	  return customer;
      }
      public List<Employee> createEmployee(List<Employee> employee )
      {
    	  try {
	    	  Employee emp=new Employee();
	    	  System.out.println("emp id ");
	    	  emp.setEmpid(scanner.nextLine());
	    	  System.out.println("password ");
	    	  emp.setPassword(scanner.nextLine());
	    	  System.out.println("name  ");
	    	  emp.setEmpname(scanner.nextLine());
	    	  System.out.println("designation ");
	    	  emp.setDesignation(scanner.nextLine());
	    	  System.out.println("branch id ");
	    	  emp.setBranchid(scanner.nextLine());
	    	  employee.add(emp);
	    	  System.out.println("added successfully ");
    	  }catch(Exception e) {
    		  e.printStackTrace();
    	  }
    	  return employee;
    	  
      }
      
      public List<Customer> viewCustomer(List<Customer> customer )
      {
    	  System.out.println("enter id of customer :");
    	  String str=scanner.nextLine();
    	  int flag=0;
    	  for(Customer cst:customer)
    	  {
    		  if(cst.getCustid().equals(str))
    		  {
    			  flag=1;
    			  System.out.println("customerId : "+cst.getCustid()+"  "+"customerName : "+cst.getCustname()+"  "+"customerContact : "+cst.getContact()); 
    		 }
    		  
    	  }
    	  if(flag==0)
    		 
    			  System.out.println("no such customer exist....");
    		  
    	  return customer;
      }
	public List<Employee> deleteEmployee(List<Employee> employee) {
		// 101,102,103
	  	  System.out.println("enter id of employee you want to delete :");
	  	  String str=scanner.nextLine();
	  	  System.out.println(employee);
	     List<Employee> filteredCollection = employee
			  .stream()
			  .filter(emp -> !emp.getEmpid().equals(str))
			  .collect(Collectors.toList());
		System.out.println("deleted ....");
		
		  
		 
		return filteredCollection;
  	  
	}
      
}
