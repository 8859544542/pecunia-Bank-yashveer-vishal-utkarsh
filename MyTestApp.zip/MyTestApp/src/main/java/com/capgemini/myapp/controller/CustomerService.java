package com.capgemini.myapp.controller;

import java.util.ArrayList;
import java.util.List;

import com.capgemini.myapp.model.Customer;

public class CustomerService {


	public void  viewDetails(Customer customer)
	{
		 
			  System.out.println("customerId : "+customer.getCustid()+"  "+"customerName : "+customer.getCustname()+"  "+"customerContact : "+customer.getContact());
			  System.out.println("---------------------------------------");
		  
		 
	}
	public void dueAmount(Customer customer)
	{
		System.out.println("customer current loan amount is :"+customer.getLoanamount());
		
	}
	public void lastPayment(Customer customer)
	{
		
	}
	public void emiCalculation(Customer customer)
	{
		System.out.println("your loan amount is : "+customer.getLoanamount());
		Double amt=customer.getLoanamount()+0.2*customer.getLoanamount();
		System.out.println("your monthly EMI is :"+(amt/12));
	}

}
