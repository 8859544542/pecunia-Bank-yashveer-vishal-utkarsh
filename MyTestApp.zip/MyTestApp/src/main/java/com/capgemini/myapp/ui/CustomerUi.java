package com.capgemini.myapp.ui;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.capgemini.myapp.controller.CustomerService;
import com.capgemini.myapp.controller.ManagerService;
import com.capgemini.myapp.dao.LocationInfo;
import com.capgemini.myapp.model.Customer;

public class CustomerUi {
	Scanner scanner=new Scanner(System.in);
	public void customerLogin(List<Customer> customer)
	{
		 int i;
		 System.out.println("enter user id ...");
		 String str=scanner.nextLine();
		 System.out.println("enter password...");
		 String password=scanner.nextLine();
		 for(Customer cs1:customer)
		 {
			
		 if(cs1.getCustid().equals(str)&& cs1.getCustpass().equals(password))
		 {
			 do
			 {
			    System.out.println("1 for View_details ");
				System.out.println("2 for Due_Amount");
				System.out.println("3 for Last_payment ");
			    System.out.println("4 for emi calculation ");
				System.out.println("5 for quit");
				List<Customer> cust=customer;
		        CustomerService cs=new CustomerService();
				switch(scanner.nextInt())
				{
				case 1:
					    cs.viewDetails(cs1);
					    System.out.println("---------------------------------------");
					    break;
				case 2:
					   cs.dueAmount(cs1 );
					   System.out.println("---------------------------------------");
					   break;
				case 3:
					    cs.lastPayment( cs1 );
					    System.out.println("---------------------------------------");
				        break;
				case 4:
					     cs.emiCalculation(cs1 );
					     System.out.println("---------------------------------------");
				         break;
				case 5:System.exit(0);
				
				default:System.out.println("wrong choice....");
					
				
				}
				try {
					FileOutputStream fout = new FileOutputStream(LocationInfo.pathCustomer);
				 	ObjectOutputStream oos = new ObjectOutputStream(fout);
				 	try {
						oos.writeObject(cust);
					} catch (IOException e) {
						e.printStackTrace();
					}
				}catch(Exception e) {
					e.printStackTrace();
				}
				 System.out.println("press 9 for continue ....");
			     i=scanner.nextInt();
				}while(i==9);
				
				
				
		 }
		 }
	}
}
		
	
	

